public class Employee{
  private String id;
  private String firstName;
  private String lastName;
  private String email;
  private String gender;
  private int age;
public Employee(String id, String firstName, String lastName, String email, String gender, int age) {
  this.id = id;//keyword refers to the objects in the constructor
  this.firstName = firstName;
  this.lastName = lastName;
  this.email = email;
  this.gender = gender;
  this.age = age;
} // getter and setter are used to get and set  the fields of a class without you dircetly accessing the field also allows easier changes down the road to add extra info for example in the future you can use it to validate the input you use to set the field 
public String getId() {
  return id;
}
public void setId(String id) {
  this.id = id;
}
public String getFirstName() {
  return firstName;
}
public void setFirstName(String firstName) {
  this.firstName = firstName;
}
public String getLastName() {
  return lastName;
}
public void setLastName(String lastName) {
  this.lastName = lastName;
}
public String getEmail() {
  return email;
}
public void setEmail(String email) {
  this.email = email;
}
public String getGender() {
  return gender;
}
public void setGender(String gender) {
  this.gender = gender;
}
public int getAge() {
  return age;
}
public void setAge(int age) {
  this.age = age;
}
@Override //formats the way the output is printed similer to a printf 
public String toString() {
  return String.format("%s,%s,%s,%s,%s,%d",id,firstName,lastName,email,gender,age);
}
}
