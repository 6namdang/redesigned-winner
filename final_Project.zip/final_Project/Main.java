import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.function.Function;
import java.util.Comparator;

public class Main{
  public static void main(String[] args){
    Scanner scanner = null;
    ArrayList<Employee> employees = new ArrayList<>();
    try{ //so it doesnt find throw the file not found error if file not found it just exist code
      scanner = new Scanner(new File("./mock-data.csv"));
      scanner.nextLine();
    }
    catch(Exception e){
      System.out.println("Failed to load data set");
      System.exit(1);//program catches erroer so that it doesnt stop running;
    }
    while(scanner.hasNextLine()){ //checks if thier is next row
      String line = scanner.nextLine();
      String[] parsedLine = line.split(",");//splits line so that everything is not stuck together
      Employee employee = new Employee(parsedLine[0], parsedLine[1], parsedLine[2], parsedLine[3], parsedLine[4], Integer.parseInt(parsedLine[5]));
      employees.add(employee);
    }
    //returns a comparotor to use based on the implemented function  built inot funtional interface java.util

    //used method reference which is the same as implemented the Function interface and inside the apply method calling the one method if the imput class;
    Comparator<Employee> comparatorByFirstName = Comparator.comparing(Employee::getFirstName);
    //same as the above because all i am doing is calling a method of the passed class parameter of employee so i can use a shortcut of method reference to do same thing;
    Comparator<Employee> comparatorByFirstName2 = Comparator.comparing(new Function<Employee,String>() {
		@Override
		public String apply(Employee e) {
      return e.getFirstName();
		}
    });
    Comparator<Employee> comparatorByLastName = Comparator.comparing(Employee::getLastName);
    Comparator<Employee> comparatorByGender = Comparator.comparing(Employee::getGender);
    Comparator<Employee> comparatorByAge = Comparator.comparing(Employee::getAge);
    Comparator<Employee> comparatorByID = Comparator.comparing(Employee::getId);
    Employee[] employeesArray = employees.toArray(new Employee[0]);
    System.out.println("sorted by first name");
    MergeSort.sort(employeesArray,0,employeesArray.length-1,comparatorByFirstName);
    for(int i = 0; i < 20; i++){
      System.out.println(employeesArray[i]);
    }
    System.out.println();
    System.out.println("Sorted by last name");
    MergeSort.sort(employeesArray,0,employeesArray.length-1,comparatorByLastName);
    for(int i = 0; i < 20; i++){
      System.out.println(employeesArray[i]);
    }
    System.out.println();
    System.out.println("sorted by gender");
    MergeSort.sort(employeesArray,0,employeesArray.length-1,comparatorByGender);
    for(int i = 0; i < 20; i++){
      System.out.println(employeesArray[i]);
    }
    System.out.println();
    System.out.println("Sorted by Age");
    MergeSort.sort(employeesArray,0,employeesArray.length-1,comparatorByAge);
    for(int i = 0; i < 20; i++){
      System.out.println(employeesArray[i]);
    }
    System.out.println();
    System.out.println("Sorted by ID");
    MergeSort.sort(employeesArray,0,employeesArray.length-1,comparatorByID);
    for(int i = 0; i < 20; i++){
      System.out.println(employeesArray[i]);
    }
  }
}
