import java.util.Arrays;
import java.util.Comparator;

public class MergeSort{
  private static <T> void merge(T[] a, int l, int m, int r,Comparator<T> c){
    int i = 0, j = 0, k = l;
    int ls =  (m - l) + 1, rs = r- m;
    T[] la = Arrays.copyOfRange(a, l,m + 1);
    T[] ra = Arrays.copyOfRange(a, m + 1, r + 1);
    while(i < ls && j < rs){
      a[k++] = c.compare(la[i], ra[j]) < 0 ? la[i++]: ra[j++];
    }
    System.arraycopy(la, i , a, k , ls - i);
    System.arraycopy(ra, j , a, k , rs - j);//copies array from specified position to picked destination
  } //makes the method generic that mean everytime i reference i am referencign a type so verytime you use T or any other variable u want that in the method the complier changes the time at runtim
  public static <T> void sort(T[] a, int l, int r,Comparator<T> c){
    if(l >= r) return;
    int m = l + ((r -l) / 2);
    sort(a, l, m,c);
    sort(a, m + 1, r,c);
    merge(a, l, m, r,c);
  }
}
